# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="2.5.1"></a>
## [2.5.1](https://github.com/crlcu/multiselect/compare/v2.5.0...v2.5.1) (2018-04-27)


### Patches

* change the value for the main path ([22414f8](https://github.com/crlcu/multiselect/commit/22414f8))

### Features

* add afterInit event ([22e1523](https://github.com/crlcu/multiselect/commit/22e1523))



<a name="2.5.0"></a>
# [2.5.0](https://github.com/crlcu/multiselect/compare/v2.4.1...v2.5.0) (2018-02-06)


### Features

* now we can have different sort functions for left and right ([887ab4a](https://github.com/crlcu/multiselect/commit/887ab4a))
