$(document).ready(function() {
	$('#cat').multiselect({
		nonSelectedText: 'Select Teams'
	});
});
