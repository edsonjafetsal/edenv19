<?php
/////// CONEXIÓN A LA BASE DE DATOS /////////
$host = 'localhost';
$basededatos = 'dolibarr_nj';
$usuario = 'root';
$contraseña = 'root';

$conexion = new mysqli($host, $usuario, $contraseña, $basededatos);
if ($conexion -> connect_errno)
{
	die("Fallo la conexion:(".$conexion -> mysqli_connect_errno().")".$conexion-> mysqli_connect_error());
}





if(isset($_POST['rowid'])){ $rowid   =   $_POST['rowid'];}

$query="UPDATE llx_commande_extrafields AS t2 SET t2.proc = 1 WHERE t2.fk_object = ".$_POST['rowid'].";";




$cabecerasCO=$conexion->query($query);

$num = $cabecerasCO->num_rows;



?>
