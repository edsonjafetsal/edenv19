ALTER TABLE llx_facture_extrafields ADD return_cash int(1) NULL;
ALTER TABLE llx_facture_fourn_extrafields ADD return_stock int(1) NULL;
